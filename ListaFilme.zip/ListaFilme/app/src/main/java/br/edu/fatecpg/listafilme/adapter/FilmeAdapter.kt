package br.edu.fatecpg.listafilme.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.listafilme.R
import br.edu.fatecpg.listafilme.model.Filme

class FilmeAdapter(private val filme: Filme):
    RecyclerView.Adapter<FilmeAdapter.ViewHolder>(){
    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){

        val txv_filmes = itemView.findViewById<TextView>(R.id.txv_filmes)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_lista,parent,false)
        return ViewHolder(view)

    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val filme = filme[position]
        holder.txv_filmes.text = Filme.nome
        val diretor = filme[position]
        holder.txv_filmes.text = Filme.titulo

    }

    override fun getItemCount(): Int {
        return filme.size
    }



}
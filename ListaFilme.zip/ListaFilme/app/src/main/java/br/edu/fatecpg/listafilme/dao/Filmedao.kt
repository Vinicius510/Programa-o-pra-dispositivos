package br.edu.fatecpg.listafilme.dao

import br.edu.fatecpg.listafilme.model.Filme

interface Filmedao {

    fun adicionarFilme(titulo: Filme)
    fun obterFilme(): List<Filme>
    fun adicionarDiretor(diretor: Filme)
    fun obterDiretor(): List<Filme>
}
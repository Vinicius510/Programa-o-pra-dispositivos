package br.edu.fatecpg.listafilme

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.listafilme.dao.FilmedaoIMPL
import br.edu.fatecpg.listafilme.model.Filme
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    val dao = FilmedaoIMPL()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edt_filme = findViewById<EditText>(R.id.edt_filme)
        val edt_diretor = findViewById<EditText>(R.id.edt_diretor)
        val btn_salvar = findViewById<Button>(R.id.btn_salvar)
        val fab_proximo = findViewById<FloatingActionButton>(R.id.fab_proximo)

        btn_salvar.setOnClickListener {

            val titulo = edt_filme.text.toString()
            val diretor = edt_diretor.text.toString()
            val Titulo = Filme(titulo)
            val Diretor = Filme(diretor)
            dao.adicionarFilme(Titulo)
            dao.adicionarDiretor(Diretor)
            Toast.makeText(this, "Filme Salvo!", Toast.LENGTH_SHORT).show()
            edt_filme.text.clear()

        }
        fab_proximo.setOnClickListener{

            val intent = Intent(this, lista::class.java)
            startActivity(intent)

        }
        }
    }

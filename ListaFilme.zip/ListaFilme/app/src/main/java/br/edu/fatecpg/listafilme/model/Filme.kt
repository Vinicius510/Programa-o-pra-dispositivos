package br.edu.fatecpg.listafilme.model

class Filme(titulo: String) {

    val titulo:String = ""
    val diretor:String = ""

}
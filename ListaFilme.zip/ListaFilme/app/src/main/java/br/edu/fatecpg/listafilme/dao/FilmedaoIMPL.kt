package br.edu.fatecpg.listafilme.dao

import br.edu.fatecpg.listafilme.model.Filme

class FilmedaoIMPL:Filmedao{

  companion object{

       private val filmes = mutableListOf<Filme>()
      private val diretores = mutableListOf<Filme>()
   }

    override fun adicionarFilme(titulo: Filme) {
        Companion.filmes.add(titulo)

    }

    override fun obterFilme(): List<Filme> {

        return Companion.filmes
    }

    override fun adicionarDiretor(nome: Filme){

        Companion.diretores.add(nome)
    }
     override fun obterDiretor(): List<Filme>{

         return Companion.filmes

     }

}